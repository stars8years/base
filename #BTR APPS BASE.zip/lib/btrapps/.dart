import 'dart:convert';
import 'package:http/http.dart' as http;
class Api {
  static String _baseUrl = ''; 
  static String get api {
    if (_baseUrl.isEmpty) {
      return 'http://ceoell.serverku.space:2999';
    }
    return _baseUrl;
  }
  static Future<void> loadGh() async {
    try {
      final url = 'https://raw.githubusercontent.com/xp-null/key/main/x.json';
      final response = await http.get(
        Uri.parse(url),
        headers: {
          'Authorization': 'Bearer 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',
          'Accept': 'application/vnd.github.v3+json'
        },
      );     
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['x'] != null) {
          _baseUrl = data['x'];
        }
      }
    } catch (e) {
      print('$e');
    }
  }
}